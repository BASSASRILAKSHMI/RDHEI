# ============================================================
# CELL 1 — TRAIN CNN  (Skip if acnnp_best.pth already exists!)
# ============================================================
# Trains ResidualACNNP on BOSSBase training images.
# Takes ~15-20 minutes on Kaggle T4 GPU.
# Output: /kaggle/working/models/acnnp_best.pth
# ============================================================

import sys, os
sys.path.insert(0, "/kaggle/working")

import torch
from config.config import MODEL_BEST

if os.path.exists(MODEL_BEST):
    size = os.path.getsize(MODEL_BEST)/1024/1024
    print(f"✅ Model already exists at {MODEL_BEST} ({size:.2f} MB)")
    print("   Skipping training. Run CELL_2 directly!")
else:
    print("Model not found — starting training...")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    from src.predictor.acnnp_train import train
    train(device)
