import os
import sys
import numpy as np
sys.path.append('/content/drive/MyDrive/RN_DPE_RDHEI')
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.hmac import HMAC
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey
)
from cryptography.exceptions import InvalidSignature


def compute_hmac(image_bytes, Kmac):
    '''
    Computes HMAC-SHA256 over encrypted image

    HMAC = Hash based Message Authentication Code
    Like a fingerprint of the image!
    If even 1 pixel changes
    fingerprint completely changes!

    image_bytes = encrypted image as bytes
    Kmac        = secret key for HMAC

    Returns 32-byte HMAC tag
    '''
    h = HMAC(Kmac, hashes.SHA256())
    h.update(image_bytes)
    tag = h.finalize()
    return tag


def verify_hmac(image_bytes, Kmac, tag):
    '''
    Verifies HMAC tag
    Returns True if image not tampered!
    Returns False if image was changed!
    '''
    h = HMAC(Kmac, hashes.SHA256())
    h.update(image_bytes)
    try:
        h.verify(tag)
        return True
    except InvalidSignature:
        return False


def generate_signing_keypair():
    '''
    Generates Ed25519 keypair for ECDSA signing

    signing_key    = Alice keeps this secret!
    verification_key = Alice shares with Charlie

    Ed25519 = fast and secure signing algorithm
    Used by SSH, TLS, and blockchain! ✅
    '''
    signing_key      = Ed25519PrivateKey.generate()
    verification_key = signing_key.public_key()
    return signing_key, verification_key


def sign_package(data_bytes, signing_key):
    '''
    Alice signs the encrypted image + HMAC tag
    Creates digital signature

    Only Alice can create this signature!
    Anyone can VERIFY it but cannot FAKE it!
    '''
    signature = signing_key.sign(data_bytes)
    return signature


def verify_signature(data_bytes, signature, verification_key):
    '''
    Verifies digital signature
    Returns True  = came from real Alice! ✅
    Returns False = fake sender! ❌
    '''
    try:
        verification_key.verify(signature, data_bytes)
        return True
    except InvalidSignature:
        return False


def image_to_bytes(image):
    '''
    Converts numpy image array to bytes
    Needed for HMAC and signing!
    '''
    return image.astype(np.uint8).tobytes()


def create_secure_package(encrypted_image, Kmac, signing_key):
    '''
    Creates complete secure package:
    1. Compute HMAC over encrypted image
    2. Sign (image + HMAC) with Alice private key
    3. Return package with all parts

    Bob receives this package!
    '''
    # Convert image to bytes
    img_bytes = image_to_bytes(encrypted_image)

    # Step 1: Compute HMAC
    hmac_tag = compute_hmac(img_bytes, Kmac)

    # Step 2: Sign image + HMAC together
    package_bytes = img_bytes + hmac_tag
    signature     = sign_package(package_bytes, signing_key)

    package = {
        'encrypted_image' : encrypted_image,
        'hmac_tag'        : hmac_tag,
        'signature'       : signature,
    }

    return package


def verify_package(package, Kmac, verification_key):
    '''
    Charlie verifies the received package:
    1. Verify ECDSA signature (real sender?)
    2. Verify HMAC (no tampering?)

    Returns:
    True  = package is authentic and untampered! ✅
    False = something wrong! ❌
    '''
    encrypted_image = package['encrypted_image']
    hmac_tag        = package['hmac_tag']
    signature       = package['signature']

    img_bytes     = image_to_bytes(encrypted_image)
    package_bytes = img_bytes + hmac_tag

    # Step 1: Verify signature
    sig_valid = verify_signature(
        package_bytes, signature, verification_key
    )

    if not sig_valid:
        print('  ECDSA verification FAILED!')
        print('  Package may be from fake sender!')
        return False

    # Step 2: Verify HMAC
    hmac_valid = verify_hmac(img_bytes, Kmac, hmac_tag)

    if not hmac_valid:
        print('  HMAC verification FAILED!')
        print('  Image was tampered with!')
        return False

    return True


def verify_authentication():
    print('=' * 55)
    print('     AUTHENTICATION VERIFICATION')
    print('=' * 55)

    # Fake encrypted image for testing
    np.random.seed(42)
    fake_image = np.random.randint(
        0, 256, (32, 32), dtype=np.uint8
    )
    print('  Test image created (32x32)')

    # Fake Kmac
    Kmac = os.urandom(32)

    # Generate signing keypair
    signing_key, verification_key = generate_signing_keypair()
    print('  Signing keypair generated!')

    # Create secure package
    package = create_secure_package(
        fake_image, Kmac, signing_key
    )
    print('  Secure package created!')
    print('  HMAC tag size : ' + str(len(package['hmac_tag'])) + ' bytes')
    print('  Signature size: ' + str(len(package['signature'])) + ' bytes')

    # Test 1: Verify valid package
    print('  Test 1: Valid package...')
    result = verify_package(package, Kmac, verification_key)
    print('  Result: ' + ('AUTHENTIC!' if result else 'FAILED!'))

    # Test 2: Tampered image
    print('  Test 2: Tampered image...')
    tampered_package = {
        'encrypted_image' : package['encrypted_image'].copy(),
        'hmac_tag'        : package['hmac_tag'],
        'signature'       : package['signature'],
    }
    # Change one pixel
    tampered_package['encrypted_image'][0,0] = 255
    result2 = verify_package(
        tampered_package, Kmac, verification_key
    )
    print('  Result: ' + ('AUTHENTIC!' if result2 else 'TAMPERED DETECTED!'))

    # Test 3: Wrong key
    print('  Test 3: Wrong Kmac...')
    wrong_Kmac = os.urandom(32)
    result3    = verify_package(
        package, wrong_Kmac, verification_key
    )
    print('  Result: ' + ('AUTHENTIC!' if result3 else 'WRONG KEY DETECTED!'))

    print('=' * 55)
    print('  Authentication verified!')
    print('=' * 55)

    return package