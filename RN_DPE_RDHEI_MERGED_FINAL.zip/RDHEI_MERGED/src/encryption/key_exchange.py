import os
import sys
import numpy as np
sys.path.insert(0, "/kaggle/working")
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey, X25519PublicKey
)
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.hmac import HMAC


def generate_keypair():
    '''
    Generates ECDH keypair.
    Returns (private_key_object, public_key_bytes).
    Public key bytes = 32 raw bytes (easy to share/save).
    '''
    private_key = X25519PrivateKey.generate()
    public_key  = private_key.public_key()
    pub_bytes   = public_key.public_bytes(
        encoding = serialization.Encoding.Raw,
        format   = serialization.PublicFormat.Raw
    )
    return private_key, pub_bytes


def compute_shared_secret(private_key, other_public_key):
    '''
    Computes ECDH shared secret.
    other_public_key can be:
      - raw bytes (32 bytes)  ← from generate_keypair()
      - X25519PublicKey object ← for backward compatibility
    Both Alice and Charlie call this and get the SAME result.
    '''
    if isinstance(other_public_key, (bytes, bytearray)):
        other_pub = X25519PublicKey.from_public_bytes(bytes(other_public_key))
    else:
        other_pub = other_public_key
    return private_key.exchange(other_pub)


def derive_keys(shared_secret, nonce):
    '''
    Derives 3 sub-keys from shared secret using HKDF-SHA256.
    Returns dict: {'Kenc', 'Kmac', 'Ksbox'}
    Each key = 32 bytes.
    nonce makes keys unique per image.
    '''
    salt = nonce

    kdf_enc = HKDF(algorithm=hashes.SHA256(), length=32,
                   salt=salt, info=b'encryption')
    Kenc = kdf_enc.derive(shared_secret)

    kdf_mac = HKDF(algorithm=hashes.SHA256(), length=32,
                   salt=salt, info=b'authentication')
    Kmac = kdf_mac.derive(shared_secret)

    kdf_sbox = HKDF(algorithm=hashes.SHA256(), length=32,
                    salt=salt, info=b'sbox')
    Ksbox = kdf_sbox.derive(shared_secret)

    return {'Kenc': Kenc, 'Kmac': Kmac, 'Ksbox': Ksbox}


def generate_nonce():
    '''Generates random 32-byte nonce. Makes keys unique per image.'''
    return os.urandom(32)


def get_public_key_bytes(public_key):
    '''Converts X25519PublicKey object to raw bytes (if needed).'''
    if isinstance(public_key, (bytes, bytearray)):
        return bytes(public_key)
    return public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw
    )


def verify_keys():
    print('=' * 55)
    print('     KEY EXCHANGE VERIFICATION')
    print('=' * 55)
    alice_private, alice_pub   = generate_keypair()
    charlie_private, charlie_pub = generate_keypair()
    print('  Alice and Charlie keypairs generated!')

    alice_shared   = compute_shared_secret(alice_private,   charlie_pub)
    charlie_shared = compute_shared_secret(charlie_private, alice_pub)

    match = alice_shared == charlie_shared
    print('  Shared secret match : ' + ('YES!' if match else 'NO!'))

    nonce = generate_nonce()
    alice_keys   = derive_keys(alice_shared,   nonce)
    charlie_keys = derive_keys(charlie_shared, nonce)

    kenc_match  = alice_keys['Kenc']  == charlie_keys['Kenc']
    kmac_match  = alice_keys['Kmac']  == charlie_keys['Kmac']
    ksbox_match = alice_keys['Ksbox'] == charlie_keys['Ksbox']

    print('  Kenc  match : ' + ('YES!' if kenc_match  else 'NO!'))
    print('  Kmac  match : ' + ('YES!' if kmac_match  else 'NO!'))
    print('  Ksbox match : ' + ('YES!' if ksbox_match else 'NO!'))
    print('=' * 55)
    if kenc_match and kmac_match and ksbox_match:
        print('  ALL KEYS MATCH! Key exchange verified!')
    print('=' * 55)
    return alice_keys, nonce
