import numpy as np
import sys
from scipy.integrate import odeint
sys.path.append('/content/drive/MyDrive/RN_DPE_RDHEI')

# Discard first N values of chaos sequence
# Why? Chaos needs warmup time to become truly random!
# First 1000 values are predictable (transient)
# After 1000 values = fully chaotic! ✅
TRANSIENT = 1000


def seed_from_key(key_bytes):
    '''
    Converts key bytes to float seed
    for chaos equations

    Chaos equations need float input
    between 0.1 and 0.9!
    Key bytes are integers 0-255
    We convert them to floats!
    '''
    import hashlib
    # Use SHA256 hash of key bytes
    # This gives well distributed seed!
    hash_bytes = hashlib.sha256(key_bytes).digest()

    # Convert first 4 bytes to integer
    seed_int = int.from_bytes(hash_bytes[:4], 'big')

    # Map to range 0.1 to 0.9
    # This avoids chaos collapse at 0 or 1!
    seed = 0.1 + (seed_int / (2**32)) * 0.8

    return seed


def generate_lss_sequence(seed, length):
    '''
    LSS = Logistic Sine System
    Uses standard logistic map:
    x(n+1) = r * x(n) * (1 - x(n))

    Why logistic map?
    Simple, proven chaos equation!
    Works reliably for r=3.99
    Used for block permutation (H1)

    seed   = starting value (from Kenc)
    length = how many values we need
    '''
    r = 3.99  # chaos parameter
    x = seed
    sequence = []

    # Generate values
    for i in range(TRANSIENT + length):
        # Standard logistic map
        x = r * x * (1 - x)
        # Only keep values after transient
        if i >= TRANSIENT:
            sequence.append(float(x))

    return np.array(sequence)


def lorenz_system(state, t, sigma, rho, beta):
    '''
    Lorenz differential equations
    Famous chaos system discovered in 1963!

    dx/dt = sigma * (y - x)
    dy/dt = x * (rho - z) - y
    dz/dt = x * y - beta * z

    sigma, rho, beta = system parameters
    These specific values create chaos!
    '''
    x, y, z = state
    dxdt = sigma * (y - x)
    dydt = x * (rho - z) - y
    dzdt = x * y - beta * z
    return [dxdt, dydt, dzdt]


def generate_lorenz_sequences(seed, length):
    '''
    Generates H2 and H3 using Lorenz system

    H2 = from y values → S-box substitution
    H3 = from z values → DPC block offsets

    seed   = starting value from Kenc
    length = how many values needed
    '''
    # Lorenz parameters that create chaos
    sigma = 10.0
    rho   = 28.0
    beta  = 8.0 / 3.0

    # Initial state from seed
    x0 = seed
    y0 = seed * 1.1  # slightly different
    z0 = seed * 0.9  # slightly different
    state0 = [x0, y0, z0]

    # Time points
    # More points = more chaos values
    total_steps = TRANSIENT + length
    t = np.linspace(0, total_steps * 0.01, total_steps)

    # Solve Lorenz ODE
    solution = odeint(
        lorenz_system,
        state0,
        t,
        args=(sigma, rho, beta)
    )

    # Extract y and z after transient
    H2_raw = solution[TRANSIENT:, 1]  # y values
    H3_raw = solution[TRANSIENT:, 2]  # z values

    # Normalize to 0-1 range
    # Why? We need values between 0 and 1
    # for building S-box and computing offsets
    def normalize(arr):
        mn = arr.min()
        mx = arr.max()
        return (arr - mn) / (mx - mn + 1e-10)

    H2 = normalize(H2_raw)
    H3 = normalize(H3_raw)

    return H2, H3


def generate_all_sequences(Kenc, image_size):
    '''
    Generates ALL chaos sequences
    needed for encryption

    INPUT:
    Kenc       = 32 byte key from HKDF
    image_size = (H, W) of image

    OUTPUT:
    H1 = shuffle sequence for block permutation
    H2 = substitution sequence for S-box
    H3 = offset sequence for DPC cipher
    '''
    H, W         = image_size
    total_pixels = H * W
    num_blocks   = (H // 4) * (W // 4)

    # Convert Kenc to seed
    seed = seed_from_key(Kenc)
    print('  Chaos seed: ' + str(round(seed, 6)))

    # Generate H1 using LSS
    # H1 length = number of blocks
    # (one shuffle value per block)
    print('  Generating H1 (LSS)...')
    H1 = generate_lss_sequence(seed, num_blocks)

    # Generate H2 and H3 using Lorenz
    # H2 length = 256 (one per pixel value)
    # H3 length = number of blocks
    print('  Generating H2, H3 (Lorenz)...')
    H2, H3 = generate_lorenz_sequences(seed, max(256, num_blocks))

    # Trim to needed lengths
    H2 = H2[:256]        # 256 values for S-box
    H3 = H3[:num_blocks] # one per block for DPC

    return H1, H2, H3


def verify_chaos():
    print('=' * 55)
    print('     CHAOS ENGINE VERIFICATION')
    print('=' * 55)

    # Use fake Kenc for testing
    fake_Kenc = bytes(range(32))

    # Generate sequences for small image
    print('  Generating chaos sequences...')
    H1, H2, H3 = generate_all_sequences(
        fake_Kenc, (32, 32)
    )

    print('  H1 shape : ' + str(H1.shape))
    print('  H2 shape : ' + str(H2.shape))
    print('  H3 shape : ' + str(H3.shape))

    print('  H1 range : ' + str(round(H1.min(),3)) + ' to ' + str(round(H1.max(),3)))
    print('  H2 range : ' + str(round(H2.min(),3)) + ' to ' + str(round(H2.max(),3)))
    print('  H3 range : ' + str(round(H3.min(),3)) + ' to ' + str(round(H3.max(),3)))

    # Verify reproducibility
    # Same Kenc should give same sequences!
    print('  Verifying reproducibility...')
    H1b, H2b, H3b = generate_all_sequences(
        fake_Kenc, (32, 32)
    )

    h1_match = np.allclose(H1, H1b)
    h2_match = np.allclose(H2, H2b)
    h3_match = np.allclose(H3, H3b)

    print('  H1 reproducible : ' + ('YES!' if h1_match else 'NO!'))
    print('  H2 reproducible : ' + ('YES!' if h2_match else 'NO!'))
    print('  H3 reproducible : ' + ('YES!' if h3_match else 'NO!'))

    print('=' * 55)
    if h1_match and h2_match and h3_match:
        print('  Chaos engine verified!')
    else:
        print('  Something wrong!')
    print('=' * 55)

    return H1, H2, H3