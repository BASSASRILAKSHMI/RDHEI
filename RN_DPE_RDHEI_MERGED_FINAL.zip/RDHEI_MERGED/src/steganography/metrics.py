import numpy as np
import sys
sys.path.append('/content/drive/MyDrive/RN_DPE_RDHEI')


def calculate_psnr(original, recovered):
    '''
    PSNR = Peak Signal to Noise Ratio
    Measures image quality after recovery

    PSNR = infinity means PERFECT recovery!
    Every pixel exactly same as original!

    Higher PSNR = better quality
    Our target  = infinity (lossless!) ✅
    '''
    orig = original.astype(np.float64)
    rec  = recovered.astype(np.float64)
    mse  = np.mean((orig - rec) ** 2)
    if mse == 0:
        return float('inf')
    psnr = 10 * np.log10(255.0 ** 2 / mse)
    return round(psnr, 4)


def calculate_ssim(original, recovered):
    '''
    SSIM = Structural Similarity Index
    Measures structural similarity

    SSIM = 1.0 means PERFECT similarity!
    Our target = 1.0 ✅
    '''
    orig = original.astype(np.float64)
    rec  = recovered.astype(np.float64)

    # SSIM constants
    C1 = (0.01 * 255) ** 2
    C2 = (0.03 * 255) ** 2

    # Means
    mu1 = np.mean(orig)
    mu2 = np.mean(rec)

    # Variances and covariance
    sigma1_sq = np.var(orig)
    sigma2_sq = np.var(rec)
    sigma12   = np.mean((orig - mu1) * (rec - mu2))

    # SSIM formula
    numerator   = (2*mu1*mu2 + C1) * (2*sigma12 + C2)
    denominator = (mu1**2 + mu2**2 + C1) * (sigma1_sq + sigma2_sq + C2)

    ssim = numerator / denominator
    return round(float(ssim), 6)


def calculate_bpp(secret_bits_count, image):
    '''
    BPP = Bits Per Pixel
    How many secret bits hidden per pixel

    Higher BPP = more data hidden
    Our target = 4.0+ bpp ✅
    Papers best = 3.9381 bpp
    '''
    H, W        = image.shape
    total_pixels = H * W
    bpp          = secret_bits_count / total_pixels
    return round(bpp, 4)


def calculate_entropy(image):
    '''
    Entropy = measure of randomness
    Higher entropy = more random = better encryption

    Max entropy = 8.0 (perfectly random)
    Our target  = 7.97 to 7.999 ✅
    '''
    img      = image.astype(np.uint8).flatten()
    hist, _  = np.histogram(img, bins=256, range=(0, 256))
    hist     = hist / hist.sum()
    # Remove zeros to avoid log(0)
    hist     = hist[hist > 0]
    entropy  = -np.sum(hist * np.log2(hist))
    return round(float(entropy), 4)


def calculate_npcr(original, encrypted):
    '''
    NPCR = Number of Pixel Change Rate
    How many pixels changed after encryption

    Higher NPCR = more pixels changed = better
    Our target  = 99%+ ✅
    '''
    orig = original.astype(np.int32)
    enc  = encrypted.astype(np.int32)
    diff = (orig != enc).astype(np.float64)
    npcr = np.mean(diff) * 100
    return round(npcr, 4)


def calculate_uaci(original, encrypted):
    '''
    UACI = Unified Average Changing Intensity
    Average intensity of pixel changes

    Target = ~33.4% ✅
    Standard result for chaotic encryption
    '''
    orig = original.astype(np.float64)
    enc  = encrypted.astype(np.float64)
    uaci = np.mean(np.abs(orig - enc)) / 255.0 * 100
    return round(uaci, 4)


def calculate_all_metrics(
    original,
    encrypted,
    recovered,
    secret_bits_count
):
    '''
    Calculates ALL metrics at once!
    Returns complete results dictionary
    '''
    metrics = {
        'PSNR'    : calculate_psnr(original, recovered),
        'SSIM'    : calculate_ssim(original, recovered),
        'BPP'     : calculate_bpp(secret_bits_count, original),
        'Entropy' : calculate_entropy(encrypted),
        'NPCR'    : calculate_npcr(original, encrypted),
        'UACI'    : calculate_uaci(original, encrypted),
    }
    return metrics


def print_metrics(metrics):
    '''
    Prints metrics in paper-ready format
    '''
    print('=' * 55)
    print('        PERFORMANCE METRICS')
    print('=' * 55)
    print('  METRIC      VALUE         TARGET')
    print('  ' + '-'*50)

    psnr = metrics['PSNR']
    psnr_str = 'infinity' if psnr == float('inf') else str(psnr)
    print('  PSNR      : ' + psnr_str + '       infinity ✅')

    print('  SSIM      : ' + str(metrics['SSIM']) + '        1.0 ✅')
    print('  BPP       : ' + str(metrics['BPP']) + '          4.0+ ✅')
    print('  Entropy   : ' + str(metrics['Entropy']) + '       7.97-7.999 ✅')
    print('  NPCR      : ' + str(metrics['NPCR']) + '%       99%+ ✅')
    print('  UACI      : ' + str(metrics['UACI']) + '%       ~33.4% ✅')
    print('=' * 55)


def verify_metrics():
    print('=' * 55)
    print('        METRICS VERIFICATION')
    print('=' * 55)

    from src.encryption.cipher import encrypt_image
    from src.steganography.embedding import text_to_bits
    from src.steganography.receiver import (
        embed_in_lsb, extract_from_lsb, recover_original
    )

    # Create test images
    np.random.seed(42)
    original = np.random.randint(
        0, 256, (32, 32), dtype=np.uint8
    )

    # Encrypt
    np.random.seed(123)
    num_blocks = (32//4) * (32//4)
    H1    = np.random.random(num_blocks)
    H2    = np.random.random(256)
    H3    = np.random.random(num_blocks)
    Ksbox = bytes(range(32))

    encrypted, enc_info = encrypt_image(
        original, H1, H2, H3, Ksbox
    )

    # Embed secret
    secret_text  = 'HELLO WORLD'
    secret_bits  = text_to_bits(secret_text)
    class_map    = np.zeros((8, 8), dtype=np.uint8)
    location_map = {
        'class_map'  : class_map,
        'block_size' : 4,
    }

    marked, bits_embedded, orig_lsbs = embed_in_lsb(
        encrypted, secret_bits, location_map
    )

    # Extract and recover
    recovered_bits, clean_enc = extract_from_lsb(
        marked, location_map,
        len(secret_bits), orig_lsbs
    )
    recovered = recover_original(clean_enc, enc_info)

    # Calculate all metrics
    metrics = calculate_all_metrics(
        original, encrypted,
        recovered, bits_embedded
    )

    # Print results
    print_metrics(metrics)

    return metrics