import numpy as np
import sys
sys.path.append('/content/drive/MyDrive/RN_DPE_RDHEI')


def text_to_bits(text):
    bits = []
    for char in text:
        ascii_val = ord(char)
        for i in range(7, -1, -1):
            bits.append((ascii_val >> i) & 1)
    return bits


def bits_to_text(bits):
    text = ''
    for i in range(0, len(bits) - 7, 8):
        byte = 0
        for j in range(8):
            byte = (byte << 1) | bits[i + j]
        text += chr(byte)
    return text


def embed_using_brbcc_planes(
    encrypted_image,
    secret_bits,
    location_map
):
    '''
    Embeds secret bits using BRBCC free planes

    For each usable block:
      For each pixel in block:
        For each FREE plane:
          Hide 1 secret bit here!

    This gives us FREE_PLANES bpp capacity!
    Example: 4 free planes = 4 bpp! ✅
    '''
    marked         = encrypted_image.copy().astype(np.uint8)
    H, W           = marked.shape
    class_map      = location_map['class_map']
    block_size     = location_map['block_size']
    free_plane_ids = location_map.get('free_plane_ids', [2,3,4,5,6,7])
    rows           = H // block_size
    cols           = W // block_size
    bit_index      = 0
    total_bits     = len(secret_bits)
    # Store original plane bits for recovery
    original_bits  = {}

    for r in range(rows):
        for c in range(cols):
            if class_map[r, c] == 2:
                continue
            row_start = r * block_size
            col_start = c * block_size
            for pr in range(block_size):
                for pc in range(block_size):
                    pixel_row = row_start + pr
                    pixel_col = col_start + pc
                    orig_pixel = int(marked[pixel_row, pixel_col])
                    for plane_id in free_plane_ids:
                        if bit_index >= total_bits:
                            break
                        # Save original bit at this plane
                        orig_bit = (orig_pixel >> plane_id) & 1
                        key = (pixel_row, pixel_col, plane_id)
                        original_bits[key] = orig_bit
                        # Set this plane bit to secret bit
                        secret_bit  = secret_bits[bit_index]
                        # Clear the plane bit then set it
                        orig_pixel  = (orig_pixel & ~(1 << plane_id)) | (secret_bit << plane_id)
                        marked[pixel_row, pixel_col] = np.uint8(orig_pixel)
                        bit_index += 1
                    if bit_index >= total_bits:
                        break
                if bit_index >= total_bits:
                    break
            if bit_index >= total_bits:
                break
        if bit_index >= total_bits:
            break

    return marked, bit_index, original_bits


def calculate_capacity(location_map):
    '''
    Calculates true capacity using free planes
    '''
    class_map      = location_map['class_map']
    block_size     = location_map['block_size']
    free_plane_ids = location_map.get('free_plane_ids', [2,3,4,5,6,7])
    usable         = int(np.sum(class_map != 2))
    pixels_per_block = block_size * block_size
    total_capacity = usable * pixels_per_block * len(free_plane_ids)
    return total_capacity


def verify_embedding():
    print('=' * 55)
    print('       EMBEDDING VERIFICATION')
    print('=' * 55)

    np.random.seed(42)
    fake_encrypted = np.random.randint(
        0, 256, (32, 32), dtype=np.uint8
    )

    # Location map with 4 free planes
    class_map    = np.zeros((8, 8), dtype=np.uint8)
    location_map = {
        'class_map'     : class_map,
        'block_size'    : 4,
        'free_plane_ids': [2, 3, 4, 5],
    }

    secret_text = 'HELLO'
    secret_bits = text_to_bits(secret_text)
    capacity    = calculate_capacity(location_map)
    print('  Secret text : ' + secret_text)
    print('  Secret bits : ' + str(len(secret_bits)) + ' bits')
    print('  Capacity    : ' + str(capacity) + ' bits')
    print('  Free planes : ' + str(len(location_map['free_plane_ids'])))
    print('  BPP         : ' + str(round(capacity/(32*32), 4)))

    marked, bits_embedded, orig_bits = embed_using_brbcc_planes(
        fake_encrypted, secret_bits, location_map
    )
    print('  Bits hidden : ' + str(bits_embedded))

    changed = not np.array_equal(fake_encrypted, marked)
    print('  Image changed: ' + str(changed))

    diff = np.abs(
        fake_encrypted.astype(np.int32) - marked.astype(np.int32)
    )
    print('  Max pixel change : ' + str(diff.max()))

    print('=' * 55)
    print('  Embedding verified!')
    print('=' * 55)

    return marked, secret_bits, location_map, orig_bits