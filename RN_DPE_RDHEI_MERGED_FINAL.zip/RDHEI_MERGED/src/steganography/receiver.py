import numpy as np
import sys
sys.path.append('/content/drive/MyDrive/RN_DPE_RDHEI')
from src.steganography.embedding import (
    bits_to_text,
    text_to_bits,
    embed_using_brbcc_planes
)


def extract_using_brbcc_planes(
    marked_image,
    location_map,
    num_bits,
    original_bits
):
    '''
    Extracts secret bits from free planes
    Restores original plane bits
    Returns secret bits AND clean image
    '''
    marked         = marked_image.copy().astype(np.uint8)
    H, W           = marked.shape
    class_map      = location_map['class_map']
    block_size     = location_map['block_size']
    free_plane_ids = location_map.get('free_plane_ids', [2,3,4,5,6,7])
    rows           = H // block_size
    cols           = W // block_size
    secret_bits    = []

    for r in range(rows):
        for c in range(cols):
            if class_map[r, c] == 2:
                continue
            row_start = r * block_size
            col_start = c * block_size
            for pr in range(block_size):
                for pc in range(block_size):
                    pixel_row  = row_start + pr
                    pixel_col  = col_start + pc
                    curr_pixel = int(marked[pixel_row, pixel_col])
                    for plane_id in free_plane_ids:
                        if len(secret_bits) >= num_bits:
                            break
                        # Read secret bit from this plane
                        secret_bit = (curr_pixel >> plane_id) & 1
                        secret_bits.append(secret_bit)
                        # Restore original bit
                        key      = (pixel_row, pixel_col, plane_id)
                        orig_bit = original_bits.get(key, 0)
                        curr_pixel = (
                            curr_pixel & ~(1 << plane_id)
                        ) | (orig_bit << plane_id)
                        marked[pixel_row, pixel_col] = np.uint8(curr_pixel)
                    if len(secret_bits) >= num_bits:
                        break
                if len(secret_bits) >= num_bits:
                    break
            if len(secret_bits) >= num_bits:
                break
        if len(secret_bits) >= num_bits:
            break

    clean_image = marked
    return secret_bits, clean_image


def recover_original(clean_encrypted, enc_info):
    from src.encryption.cipher import decrypt_image
    return decrypt_image(clean_encrypted, enc_info)


def verify_receiver():
    print('=' * 55)
    print('        RECEIVER VERIFICATION')
    print('=' * 55)

    from src.encryption.cipher import encrypt_image

    # Create original image
    np.random.seed(42)
    original = np.random.randint(
        50, 200, (32, 32), dtype=np.uint8
    )
    print('  Original image (32x32)')
    print('  Sample pixels: ' + str(original[0, :5]))

    # Encrypt
    np.random.seed(123)
    num_blocks = (32//4) * (32//4)
    H1    = np.random.random(num_blocks)
    H2    = np.random.random(256)
    H3    = np.random.random(num_blocks)
    Ksbox = bytes(range(32))

    encrypted, enc_info = encrypt_image(
        original, H1, H2, H3, Ksbox
    )
    print('  Encrypted pixels: ' + str(encrypted[0, :5]))

    # Location map with 4 free planes
    class_map    = np.zeros((8, 8), dtype=np.uint8)
    location_map = {
        'class_map'     : class_map,
        'block_size'    : 4,
        'free_plane_ids': [2, 3, 4, 5],
    }

    # Embed
    secret_text = 'HELLO WORLD'
    secret_bits = text_to_bits(secret_text)
    print('  Secret text: ' + secret_text)

    marked, bits_embedded, orig_bits = embed_using_brbcc_planes(
        encrypted, secret_bits, location_map
    )
    print('  Bits embedded: ' + str(bits_embedded))

    # Extract
    recovered_bits, clean_enc = extract_using_brbcc_planes(
        marked, location_map, len(secret_bits), orig_bits
    )
    recovered_text = bits_to_text(recovered_bits)
    text_match     = recovered_text == secret_text
    print('  Recovered text: ' + recovered_text)
    print('  Text match    : ' + ('YES!' if text_match else 'NO!'))

    # Decrypt
    recovered = recover_original(clean_enc, enc_info)
    image_match = np.array_equal(original, recovered)
    print('  Image match   : ' + ('PERFECT!' if image_match else 'NO!'))

    if image_match:
        print('  PSNR = infinity! ✅')
    else:
        diff = original.astype(np.float32) - recovered.astype(np.float32)
        mse  = np.mean(diff**2)
        if mse == 0:
            print('  PSNR = infinity! ✅')
        else:
            import math
            psnr = 10 * math.log10(255**2 / mse)
            print('  PSNR = ' + str(round(psnr, 2)) + ' dB')

    print('=' * 55)
    if text_match and image_match:
        print('  RECEIVER VERIFIED! ✅')
    else:
        print('  Something wrong!')
    print('=' * 55)

    return original, recovered, recovered_text