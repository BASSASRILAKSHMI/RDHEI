import numpy as np


def extract_bitplanes(error_image):
    '''
    Splits error image into 8 bit-planes
    Uses absolute values for bit extraction
    Stores sign separately
    Small errors (0,1,2) will have upper planes all zero
    Those upper planes = FREE SPACE for secret data!
    '''
    H, W = error_image.shape

    # Use absolute values for bit-plane extraction
    # Why: error=1 gives 00000001 → upper 7 planes are zero!
    # error=2 gives 00000010 → upper 6 planes are zero!
    # These upper zero planes = FREE SPACE!
    abs_errors = np.abs(error_image).astype(np.uint8)
    abs_errors = np.clip(abs_errors, 0, 255)

    bitplanes = np.zeros((8, H, W), dtype=np.uint8)
    for bit in range(8):
        bitplanes[bit] = (abs_errors >> bit) & 1

    return bitplanes


def find_zero_planes(bitplanes):
    '''
    Checks which bit-planes are completely zero
    All-zero plane = FREE SPACE to hide secret data!
    '''
    zero_plane_mask = []
    for bit in range(8):
        is_zero = bool(np.all(bitplanes[bit] == 0))
        zero_plane_mask.append(is_zero)
    return zero_plane_mask


def reconstruct_from_bitplanes(bitplanes, sign_map):
    '''
    Reconstructs error image from bit-planes
    Needs sign_map to restore negative errors
    '''
    H, W = bitplanes.shape[1], bitplanes.shape[2]
    reconstructed = np.zeros((H, W), dtype=np.uint8)
    for bit in range(8):
        reconstructed += (bitplanes[bit] << bit).astype(np.uint8)
    # Restore signs
    result = reconstructed.astype(np.float32)
    result[sign_map < 0] *= -1
    return result


def extract_with_sign(error_image):
    '''
    Extracts bit-planes AND saves sign map
    Returns both for complete reconstruction
    '''
    sign_map  = np.sign(error_image).astype(np.int8)
    bitplanes = extract_bitplanes(error_image)
    return bitplanes, sign_map


def get_bitplane_stats(bitplanes, zero_plane_mask):
    H, W         = bitplanes.shape[1], bitplanes.shape[2]
    total_pixels = H * W
    num_zero     = sum(zero_plane_mask)
    stats = {
        'total_pixels'    : total_pixels,
        'num_zero_planes' : num_zero,
        'zero_plane_ids'  : [i for i,z in enumerate(zero_plane_mask) if z],
        'used_plane_ids'  : [i for i,z in enumerate(zero_plane_mask) if not z],
        'free_bits'       : num_zero * total_pixels,
        'free_bpp'        : num_zero,
    }
    return stats


def verify_bitplanes():
    print('=' * 55)
    print('     BIT-PLANE EXTRACTION VERIFICATION')
    print('=' * 55)

    # Small errors like CNN produces
    test_errors = np.array([
        [ 0,  1,  0, -1,  2],
        [ 1,  0,  2,  0,  1],
        [ 0,  2,  0,  1,  0],
        [-1,  0,  1,  0,  2],
        [ 0,  1,  0, -1,  0]
    ], dtype=np.float32)

    print('  Test error image (5x5):')
    print(test_errors)

    # Extract with sign
    bitplanes, sign_map = extract_with_sign(test_errors)
    print('  Extracted ' + str(bitplanes.shape[0]) + ' bit-planes')

    # Find zero planes
    zero_mask = find_zero_planes(bitplanes)
    print('  Bit-plane analysis:')
    for i in range(8):
        status = 'ALL ZERO - FREE!' if zero_mask[i] else 'has values'
        ones   = int(np.sum(bitplanes[i]))
        print('  Plane ' + str(i+1) + ': ' + status + ' | ones: ' + str(ones))

    # Statistics
    stats = get_bitplane_stats(bitplanes, zero_mask)
    print('  Statistics:')
    print('  Total pixels    : ' + str(stats['total_pixels']))
    print('  Zero planes     : ' + str(stats['num_zero_planes']))
    print('  Zero plane ids  : ' + str(stats['zero_plane_ids']))
    print('  Free bits       : ' + str(stats['free_bits']))
    print('  Free bpp        : ' + str(stats['free_bpp']))

    # Verify reconstruction
    reconstructed = reconstruct_from_bitplanes(bitplanes, sign_map)
    match = np.allclose(reconstructed, test_errors)
    print('  Original     : ' + str(test_errors.flatten()[:5]))
    print('  Reconstructed: ' + str(reconstructed.flatten()[:5]))
    print('  Match: ' + ('PERFECT!' if match else 'MISMATCH!'))

    print('=' * 55)
    print('  Bit-plane module verified!')
    print('=' * 55)

    return bitplanes, zero_mask, stats