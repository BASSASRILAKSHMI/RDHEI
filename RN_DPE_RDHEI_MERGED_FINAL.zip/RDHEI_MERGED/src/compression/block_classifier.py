import numpy as np
import sys
sys.path.append('/content/drive/MyDrive/RN_DPE_RDHEI')
from src.compression.bitplane import extract_bitplanes, find_zero_planes, get_bitplane_stats

# Block type labels
ALL_ZERO     = 0   # all errors zero     → maximum free space
EMBEDDABLE   = 1   # small errors        → good free space
NON_EMBED    = 2   # large errors        → no free space

# Threshold: errors larger than this = non embeddable
ERROR_THRESHOLD = 3


def extract_blocks(error_image, block_size=4):
    '''
    Splits error image into blocks of block_size x block_size
    Returns list of blocks with their positions
    '''
    H, W   = error_image.shape
    blocks = []
    for row in range(0, H - block_size + 1, block_size):
        for col in range(0, W - block_size + 1, block_size):
            block = error_image[row:row+block_size, col:col+block_size]
            blocks.append({
                'block'    : block,
                'row'      : row,
                'col'      : col,
            })
    return blocks


def classify_block(block):
    '''
    Classifies one 4x4 block into:
    ALL_ZERO   = all errors are exactly 0
    EMBEDDABLE = max error <= threshold
    NON_EMBED  = max error > threshold
    '''
    abs_errors = np.abs(block)
    max_error  = np.max(abs_errors)

    if max_error == 0:
        return ALL_ZERO
    elif max_error <= ERROR_THRESHOLD:
        return EMBEDDABLE
    else:
        return NON_EMBED


def classify_all_blocks(error_image, block_size=4):
    '''
    Classifies ALL blocks in the error image

    Returns:
    classification_map : 2D array
                         same size as image / block_size
                         each cell = block type (0,1,2)
    block_list         : list of all blocks with info
    '''
    H, W = error_image.shape
    rows = H // block_size
    cols = W // block_size

    classification_map = np.zeros((rows, cols), dtype=np.uint8)
    block_list         = []

    for r in range(rows):
        for c in range(cols):
            row_start = r * block_size
            col_start = c * block_size
            block = error_image[
                row_start : row_start + block_size,
                col_start : col_start + block_size
            ]
            block_type = classify_block(block)
            classification_map[r, c] = block_type
            block_list.append({
                'block'      : block,
                'row'        : r,
                'col'        : c,
                'row_start'  : row_start,
                'col_start'  : col_start,
                'type'       : block_type,
            })

    return classification_map, block_list


def get_classification_stats(classification_map):
    '''
    Counts how many blocks of each type exist
    Estimates embedding capacity
    '''
    total         = classification_map.size
    num_allzero   = int(np.sum(classification_map == ALL_ZERO))
    num_embeddable= int(np.sum(classification_map == EMBEDDABLE))
    num_nonembed  = int(np.sum(classification_map == NON_EMBED))
    usable        = num_allzero + num_embeddable

    stats = {
        'total_blocks'      : total,
        'all_zero_blocks'   : num_allzero,
        'embeddable_blocks' : num_embeddable,
        'non_embed_blocks'  : num_nonembed,
        'usable_blocks'     : usable,
        'usable_percent'    : round(usable / total * 100, 2),
    }
    return stats


def verify_classifier():
    print('=' * 55)
    print('     BLOCK CLASSIFIER VERIFICATION')
    print('=' * 55)

    # Create test error image 16x16
    # Mix of all three block types
    test_errors = np.zeros((16, 16), dtype=np.float32)

    # Top left 4x4 = ALL ZERO block
    test_errors[0:4, 0:4] = 0

    # Top right 4x4 = EMBEDDABLE block
    test_errors[0:4, 4:8] = np.array([
        [0, 1, 0, 2],
        [1, 0, 2, 0],
        [0, 2, 0, 1],
        [2, 0, 1, 0]
    ])

    # Bottom left 4x4 = NON EMBEDDABLE block
    test_errors[4:8, 0:4] = np.array([
        [15, 23, 18, 31],
        [42, 11, 28, 35],
        [19, 44, 12, 27],
        [38, 16, 41, 22]
    ])

    print('  Test error image created (16x16)')
    print('  Block 1 (0,0): ALL ZERO')
    print('  Block 2 (0,1): EMBEDDABLE')
    print('  Block 3 (1,0): NON EMBEDDABLE')
    print('  Block 4 (1,1): ALL ZERO (rest is 0)')

    # Classify all blocks
    class_map, block_list = classify_all_blocks(test_errors, block_size=4)

    # Print classification map
    print('  Classification map (0=AllZero 1=Embed 2=NonEmbed):')
    print(class_map)

    # Print each block result
    type_names = {0: 'ALL_ZERO', 1: 'EMBEDDABLE', 2: 'NON_EMBED'}
    print('  Block details:')
    for b in block_list:
        name = type_names[b['type']]
        print('  Block (' + str(b['row']) + ',' + str(b['col']) + ') = ' + name)

    # Get stats
    stats = get_classification_stats(class_map)
    print('  Statistics:')
    print('  Total blocks      : ' + str(stats['total_blocks']))
    print('  All zero blocks   : ' + str(stats['all_zero_blocks']))
    print('  Embeddable blocks : ' + str(stats['embeddable_blocks']))
    print('  Non-embed blocks  : ' + str(stats['non_embed_blocks']))
    print('  Usable blocks     : ' + str(stats['usable_blocks']))
    print('  Usable percent    : ' + str(stats['usable_percent']) + '%')

    print('=' * 55)
    print('  Block classifier verified!')
    print('=' * 55)

    return class_map, block_list, stats