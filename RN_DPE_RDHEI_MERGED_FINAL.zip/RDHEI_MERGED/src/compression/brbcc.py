
import numpy as np
import sys
sys.path.insert(0, "/kaggle/working")


def run_brbcc(prediction_errors,
              block_size=4, threshold=3):
    H, W       = prediction_errors.shape
    int_errors = np.round(
        prediction_errors
    ).astype(np.int32)
    abs_errors = np.abs(int_errors)
    rows = H // block_size
    cols = W // block_size
    ALL_ZERO   = 0
    EMBEDDABLE = 1
    NON_EMBED  = 2
    class_map       = np.zeros(
        (rows, cols), dtype=np.uint8
    )
    usable_blocks   = 0
    all_zero_blocks = 0
    embed_blocks    = 0
    for r in range(rows):
        for c in range(cols):
            row_s = r * block_size
            col_s = c * block_size
            block = abs_errors[
                row_s:row_s+block_size,
                col_s:col_s+block_size
            ]
            max_err = int(block.max())
            if max_err == 0:
                class_map[r, c]  = ALL_ZERO
                usable_blocks   += 1
                all_zero_blocks += 1
            elif max_err <= threshold:
                class_map[r, c] = EMBEDDABLE
                usable_blocks  += 1
                embed_blocks   += 1
            else:
                class_map[r, c] = NON_EMBED
    num_free_planes = 6
    free_plane_ids  = [7,6,5,4,3,2]
    pixels_per_block = block_size * block_size
    total_payload    = (usable_blocks
                        * pixels_per_block
                        * num_free_planes)
    total_pixels     = H * W
    bpp              = total_payload / total_pixels
    location_map = {
        "class_map"       : class_map,
        "block_size"      : block_size,
        "free_plane_ids"  : free_plane_ids,
        "num_free_planes" : num_free_planes,
        "int_errors"      : int_errors,
        "abs_errors"      : abs_errors,
    }
    capacity = {
        "total_payload_bits" : total_payload,
        "bpp"                : round(bpp, 4),
        "usable_blocks"      : usable_blocks,
        "num_free_planes"    : num_free_planes,
        "all_zero_blocks"    : all_zero_blocks,
        "embed_blocks"       : embed_blocks,
    }
    return location_map, capacity
