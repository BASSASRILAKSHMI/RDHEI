
import torch
import torch.nn as nn
import numpy as np
import sys
sys.path.insert(0, "/kaggle/working")


def med_predictor_fast(img_array):
    H, W      = img_array.shape
    img_f     = img_array.astype(np.float32)
    predicted = np.zeros((H, W), dtype=np.float32)
    predicted[0, 0]  = 128.0
    predicted[0, 1:] = img_f[0, :-1]
    predicted[1:, 0] = img_f[:-1, 0]
    a = img_f[1:, :-1]
    b = img_f[:-1, 1:]
    c = img_f[:-1, :-1]
    pred = np.where(
        c >= np.maximum(a, b),
        np.minimum(a, b),
        np.where(
            c <= np.minimum(a, b),
            np.maximum(a, b),
            a + b - c
        )
    )
    predicted[1:, 1:] = pred
    return predicted


class ResidualACNNP(nn.Module):
    def __init__(self):
        super(ResidualACNNP, self).__init__()
        self.net = nn.Sequential(
            nn.Conv2d(1, 64, 3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 128, 3, padding=1),
            nn.ReLU(),
            nn.Conv2d(128, 64, 3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 1, 1),
            nn.Tanh()
        )

    def forward(self, x):
        return self.net(x) * 10.0


def build_model(device):
    model = ResidualACNNP().to(device)
    total = sum(p.numel()
                for p in model.parameters())
    print(f"  Model params : {total:,}")
    print(f"  Device       : {device}")
    return model
