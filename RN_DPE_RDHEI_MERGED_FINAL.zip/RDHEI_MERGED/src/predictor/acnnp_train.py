
import os
import sys
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
from tqdm import tqdm
import random
from PIL import Image

sys.path.insert(0, "/kaggle/working")
from config.config import *
from src.predictor.acnnp_model import (
    build_model, med_predictor_fast
)

PATCH_SIZE = 64
NUM_EPOCHS = 50
CONTEXT    = 2


class ResidualDataset(Dataset):
    """
    Residual prediction dataset!

    For each patch:
    1. Compute MED prediction
    2. Compute residual = actual - MED
    3. CNN learns to predict residual!

    Residuals are small numbers!
    = CNN errors become tiny!
    = more free bit planes!
    = higher BPP naturally! 
    """
    def __init__(self, folder_path,
                 patch_size=64,
                 patches_per_image=4):
        self.folder_path       = folder_path
        self.patch_size        = patch_size
        self.patches_per_image = patches_per_image
        self.image_files = sorted([
            f for f in os.listdir(folder_path)
            if f.endswith(".png")
        ])
        print(f"  Images        : {len(self.image_files)}")
        print(f"  Patches/image : {patches_per_image}")
        print(f"  Total patches : "
              f"{len(self.image_files)*patches_per_image}")

    def __len__(self):
        return (len(self.image_files)
                * self.patches_per_image)

    def __getitem__(self, idx):
        img_idx  = idx // self.patches_per_image
        img_path = os.path.join(
            self.folder_path,
            self.image_files[img_idx]
        )
        image     = Image.open(img_path).convert("L")
        img_array = np.array(image, dtype=np.float32)
        H, W      = img_array.shape

        # Random patch
        r = random.randint(
            CONTEXT, H - self.patch_size - CONTEXT
        )
        c = random.randint(
            CONTEXT, W - self.patch_size - CONTEXT
        )

        # Get patch with border
        patch_with_border = img_array[
            r-CONTEXT:r+self.patch_size+CONTEXT,
            c-CONTEXT:c+self.patch_size+CONTEXT
        ]

        # MED prediction on patch
        med_pred = med_predictor_fast(
            patch_with_border.astype(np.uint8)
        )

        # Target residual = actual - MED
        actual   = patch_with_border[
            CONTEXT:-CONTEXT, CONTEXT:-CONTEXT
        ]
        med_center = med_pred[
            CONTEXT:-CONTEXT, CONTEXT:-CONTEXT
        ]
        residual = actual - med_center

        # Input: normalized patch
        inp = torch.FloatTensor(
            patch_with_border / 255.0
        ).unsqueeze(0)

        # Target: normalized residual
        # Residuals typically -30 to +30
        # Normalize to -1 to +1 range
        tgt = torch.FloatTensor(
            residual / 30.0
        ).unsqueeze(0)

        return inp, tgt


def save_model(model, path):
    os.makedirs(os.path.dirname(path),
                exist_ok=True)
    torch.save(model.state_dict(), path)
    size = os.path.getsize(path)/(1024*1024)
    print(f"  Saved: {path} ({size:.2f} MB)")


def train_one_epoch(model, loader, optimizer,
                    criterion, device):
    model.train()
    total_loss  = 0.0
    num_batches = 0
    for inp, tgt in tqdm(loader, desc="Train"):
        inp = inp.to(device)
        tgt = tgt.to(device)

        pred = model(inp)

        # Crop to match target size
        c    = CONTEXT
        pred_crop = pred[:, :, c:-c, c:-c]

        loss = criterion(pred_crop, tgt)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        total_loss  += loss.item()
        num_batches += 1
    return total_loss / num_batches


def validate(model, loader, criterion, device):
    model.eval()
    total_loss  = 0.0
    num_batches = 0
    with torch.no_grad():
        for inp, tgt in tqdm(loader, desc="Val"):
            inp = inp.to(device)
            tgt = tgt.to(device)
            pred = model(inp)
            c    = CONTEXT
            pred_crop = pred[:, :, c:-c, c:-c]
            loss = criterion(pred_crop, tgt)
            total_loss  += loss.item()
            num_batches += 1
    return total_loss / num_batches


def train(device):
    print("=" * 55)
    print("   RESIDUAL CNN TRAINING")
    print("=" * 55)
    print("MED predicts first!")
    print("CNN corrects MED residual!")
    print("Expected BPP: 4.0+ naturally!")
    print("")

    print("Loading datasets...")
    train_ds = ResidualDataset(
        TRAIN_DIR, PATCH_SIZE, 4
    )
    val_ds = ResidualDataset(
        VAL_DIR, PATCH_SIZE, 4
    )

    train_loader = DataLoader(
        train_ds,
        batch_size  = BATCH_SIZE,
        shuffle     = True,
        num_workers = 4,
        pin_memory  = True
    )
    val_loader = DataLoader(
        val_ds,
        batch_size  = BATCH_SIZE,
        shuffle     = False,
        num_workers = 4,
        pin_memory  = True
    )
    print(f"  Train batches : {len(train_loader)}")
    print(f"  Val batches   : {len(val_loader)}")

    model     = build_model(device)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(
        model.parameters(),
        lr           = 1e-3,
        weight_decay = 1e-4
    )
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode     = "min",
        patience = 5,
        factor   = 0.5
    )

    print(f"\nTraining {NUM_EPOCHS} epochs...")
    print(f"  Batch size : {BATCH_SIZE}")
    print(f"  Patch size : {PATCH_SIZE}x{PATCH_SIZE}")
    print(f"  LR         : 0.001")
    print("-" * 55)

    best_val_loss = float("inf")
    log_data      = []

    for epoch in range(1, NUM_EPOCHS + 1):
        print(f"\nEpoch {epoch}/{NUM_EPOCHS}")

        train_loss = train_one_epoch(
            model, train_loader,
            optimizer, criterion, device
        )
        val_loss = validate(
            model, val_loader,
            criterion, device
        )
        scheduler.step(val_loss)
        lr = optimizer.param_groups[0]["lr"]

        print(f"  Train Loss : {train_loss:.6f}")
        print(f"  Val Loss   : {val_loss:.6f}")
        print(f"  LR         : {lr:.8f}")

        log_data.append({
            "epoch"      : epoch,
            "train_loss" : train_loss,
            "val_loss"   : val_loss,
            "lr"         : lr
        })

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            save_model(model, MODEL_BEST)
            print(f"  BEST! Val: {val_loss:.6f}")

    save_model(model, MODEL_FINAL)
    os.makedirs(LOGS_DIR, exist_ok=True)
    pd.DataFrame(log_data).to_csv(
        TRAIN_LOG, index=False
    )

    print("\n" + "=" * 55)
    print("  TRAINING COMPLETE!")
    print("=" * 55)
    print(f"  Best Val Loss : {best_val_loss:.6f}")
    print(f"  Model saved   : {MODEL_BEST}")
    print("=" * 55)
    return model
