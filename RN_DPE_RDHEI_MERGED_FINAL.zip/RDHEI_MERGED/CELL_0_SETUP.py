# ============================================================
# CELL 0 — SETUP  (Run this FIRST!)
# ============================================================
# Copies everything from dataset to /kaggle/working.
# Splits BOSSBase into train/val/test.
#
# REQUIRED KAGGLE INPUTS:
#   1. This dataset (rdhei-final-v2)
#   2. lunan0/bossbase-1-01
# ============================================================

import os, sys, shutil

WORK = "/kaggle/working"

# ── Auto-find dataset ─────────────────────────────────────────
def find_dataset():
    for root, dirs, files in os.walk("/kaggle/input"):
        if set(["src","config","models"]).issubset(set(dirs)):
            return root
        if "config.py" in files and root.endswith("config"):
            return os.path.dirname(root)
    return None

DS = find_dataset()
if DS is None:
    raise FileNotFoundError("Dataset not found! Add rdhei-final-v2 as Kaggle input.")
print(f"✅ Dataset found: {DS}")

# ── Create working dirs ───────────────────────────────────────
for d in [f"{WORK}/config", f"{WORK}/src/predictor",
          f"{WORK}/src/compression", f"{WORK}/src/encryption",
          f"{WORK}/src/steganography", f"{WORK}/models",
          f"{WORK}/logs", f"{WORK}/results",
          f"{WORK}/data/train", f"{WORK}/data/val", f"{WORK}/data/test"]:
    os.makedirs(d, exist_ok=True)
print("✅ Directories created")

# ── Copy src/ and config/ ────────────────────────────────────
for folder in ["src", "config"]:
    src_path = os.path.join(DS, folder)
    dst_path = os.path.join(WORK, folder)
    if os.path.exists(src_path):
        shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
        n = sum(len(f) for _,_,f in os.walk(dst_path))
        print(f"✅ {folder}/ copied ({n} files)")
    else:
        print(f"⚠️  {folder}/ not found in dataset")

# ── Copy model weights ───────────────────────────────────────
model_src = os.path.join(DS, "models", "acnnp_best.pth")
model_dst = os.path.join(WORK, "models", "acnnp_best.pth")
if os.path.exists(model_src):
    shutil.copy(model_src, model_dst)
    mb = os.path.getsize(model_dst)/1024/1024
    print(f"✅ acnnp_best.pth copied ({mb:.2f} MB)")
else:
    print("⚠️  acnnp_best.pth NOT FOUND — run CELL_1_TRAIN first!")

# ── Add to Python path ────────────────────────────────────────
if WORK not in sys.path:
    sys.path.insert(0, WORK)
print(f"✅ {WORK} in sys.path")

# ── Find and split BOSSBase ──────────────────────────────────
bossbase = None
all_imgs = []
for root, dirs, files in os.walk("/kaggle/input"):
    pgms = sorted([f for f in files if f.endswith('.pgm')])
    if len(pgms) > 100:
        bossbase = root; all_imgs = pgms
        print(f"✅ BOSSBase: {root} ({len(pgms)} images)")
        break

if bossbase:
    splits = [
        (all_imgs[:8000],       f"{WORK}/data/train"),
        (all_imgs[8000:9000],   f"{WORK}/data/val"),
        (all_imgs[9000:10000],  f"{WORK}/data/test"),
    ]
    for imgs, dst in splits:
        for fname in imgs:
            dst_f = os.path.join(dst, fname)
            if not os.path.exists(dst_f):
                shutil.copy(os.path.join(bossbase, fname), dst_f)
    print(f"✅ Train:{len(splits[0][0])} Val:{len(splits[1][0])} Test:{len(splits[2][0])}")
else:
    print("⚠️  BOSSBase not found — add lunan0/bossbase-1-01 as input!")

# ── Verify config ────────────────────────────────────────────
from config.config import *
print(f"\n✅ Config imported!")
print(f"   MODEL_BEST : {MODEL_BEST}")
print(f"   TEST_DIR   : {TEST_DIR}")
print(f"\n{'='*55}\n  SETUP COMPLETE!\n{'='*55}")
