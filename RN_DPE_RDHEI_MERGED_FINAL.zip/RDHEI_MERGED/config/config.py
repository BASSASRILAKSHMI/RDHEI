
import os

# ── Auto-detect dataset root (works on ANY Kaggle account) ───
def _find_dataset():
    for root, dirs, files in os.walk("/kaggle/input"):
        if set(["src","config","models"]).issubset(set(dirs)):
            return root
        if "config.py" in files and root.endswith("config"):
            return os.path.dirname(root)
    return None

_DS = _find_dataset()

BASE_DIR    = "/kaggle/working"
DATA_DIR    = os.path.join(BASE_DIR, "data")
TRAIN_DIR   = os.path.join(DATA_DIR, "train")
VAL_DIR     = os.path.join(DATA_DIR, "val")
TEST_DIR    = os.path.join(DATA_DIR, "test")
MODELS_DIR  = os.path.join(BASE_DIR, "models")
MODEL_BEST  = os.path.join(MODELS_DIR, "acnnp_best.pth")
MODEL_FINAL = os.path.join(MODELS_DIR, "acnnp_final.pth")
LOGS_DIR    = os.path.join(BASE_DIR, "logs")
TRAIN_LOG   = os.path.join(LOGS_DIR, "train_log.csv")
RESULTS_DIR = os.path.join(BASE_DIR, "results")

IMAGE_SIZE    = 512
BATCH_SIZE    = 32
NUM_EPOCHS    = 50
LEARNING_RATE = 1e-3
WEIGHT_DECAY  = 1e-4
RANDOM_SEED   = 42
BLOCK_SIZE    = 4
THRESHOLD_ZERO  = 0
CHAOS_TRANSIENT = 1000
LORENZ_DT     = 0.01
LORENZ_STEPS  = 10000
SBOX_SIZE     = 256
TRAIN_SIZE    = 8000
VAL_SIZE      = 1000
TEST_SIZE     = 1000

# ── BOSSBase auto-detect ─────────────────────────────────────
def _find_bossbase():
    for root, dirs, files in os.walk("/kaggle/input"):
        pgms = [f for f in files if f.endswith('.pgm')]
        if len(pgms) > 100:
            return root
    return None

BOSSBASE_DIR = _find_bossbase()
