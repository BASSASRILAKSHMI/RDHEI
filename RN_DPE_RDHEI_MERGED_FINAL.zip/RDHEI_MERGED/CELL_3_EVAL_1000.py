# ============================================================
# CELL 3 — 1000 IMAGE EVALUATION
# ============================================================
# Uses the exact same pipeline as CELL_2.
# Expected results:
#   BPP=5.9578, MAE=0.0516, PSNR=inf(1000/1000)
#   SSIM=1.0(1000/1000), NPCR=99.61%, Failed=0
# ============================================================

import os, sys, numpy as np, csv
from PIL import Image
import torch, hashlib, gc

for m in list(sys.modules.keys()):
    if any(x in m for x in ['cipher','encryption','steganography',
            'compression','predictor','config']):
        del sys.modules[m]
gc.collect()
if torch.cuda.is_available(): torch.cuda.empty_cache()

sys.path.insert(0, "/kaggle/working")
from config.config import *
from src.predictor.acnnp_model    import build_model, med_predictor_fast
from src.compression.brbcc        import run_brbcc
from src.encryption.key_exchange  import (
    generate_keypair, compute_shared_secret, derive_keys, generate_nonce)
from src.encryption.chaos_engine  import generate_all_sequences
from src.encryption.cipher        import encrypt_image, decrypt_image
from src.encryption.authentication import (
    generate_signing_keypair, create_secure_package, verify_package)
from src.steganography.embedding  import text_to_bits, bits_to_text
from src.steganography.metrics    import calculate_all_metrics

CONTEXT = 2; BLOCK_SIZE = 4; N_TEST = 1000

def derive_mask(key, tag, n):
    seed = int.from_bytes(hashlib.sha256(key + tag).digest()[:4], 'big')
    return np.random.RandomState(seed).randint(0, 2, n, dtype=np.uint8)

def scan(image, class_map, fp_ids, skip, payload, mode):
    result = image.copy() if mode != 'read' else None
    out = []
    rows, cols = class_map.shape
    bidx = cnt = 0
    total = len(payload) if mode != 'read' else payload
    for r in range(rows):
        for c in range(cols):
            if class_map[r, c] == 2: continue
            if bidx >= total: break
            rs = r * BLOCK_SIZE; cs = c * BLOCK_SIZE
            for pr in range(BLOCK_SIZE):
                for pc in range(BLOCK_SIZE):
                    if bidx >= total: break
                    pr_ = rs + pr; pc_ = cs + pc
                    curr = int((result if mode != 'read' else image)[pr_, pc_])
                    for pid in fp_ids:
                        if bidx >= total: break
                        if cnt < skip: cnt += 1; continue
                        if mode == 'read':
                            out.append((curr >> pid) & 1)
                        elif mode == 'write':
                            curr = (curr & ~(1 << pid)) | (payload[bidx] << pid)
                            result[pr_, pc_] = np.uint8(curr)
                        bidx += 1; cnt += 1
                if bidx >= total: break
            if bidx >= total: break
        if bidx >= total: break
    if mode == 'read': return out
    return result, bidx

def zero_free(image, class_map, fp_ids):
    result = image.copy(); rows, cols = class_map.shape
    for r in range(rows):
        for c in range(cols):
            if class_map[r, c] == 2: continue
            rs = r * BLOCK_SIZE; cs = c * BLOCK_SIZE
            for pr in range(BLOCK_SIZE):
                for pc in range(BLOCK_SIZE):
                    curr = int(result[rs+pr, cs+pc])
                    for pid in fp_ids: curr &= ~(1 << pid)
                    result[rs+pr, cs+pc] = np.uint8(curr)
    return result

def zero_all_free(image, fp_ids):
    result = image.copy()
    for r in range(result.shape[0]):
        for c in range(result.shape[1]):
            v = int(result[r, c])
            for pid in fp_ids: v &= ~(1 << pid)
            result[r, c] = np.uint8(v)
    return result

def restore_free_xor(marked, class_map, fp_ids, key_bytes, H, W):
    result = marked.copy(); rows, cols = class_map.shape
    for r in range(rows):
        for c in range(cols):
            if class_map[r, c] == 2: continue
            rs = r * BLOCK_SIZE; cs = c * BLOCK_SIZE
            for pr in range(BLOCK_SIZE):
                for pc in range(BLOCK_SIZE):
                    pr_ = rs + pr; pc_ = cs + pc
                    curr = int(result[pr_, pc_])
                    kb   = int(key_bytes[pr_ * W + pc_])
                    for pid in fp_ids:
                        curr = (curr & ~(1 << pid)) | (((kb >> pid) & 1) << pid)
                    result[pr_, pc_] = np.uint8(curr)
    return result

def build_lm(cm):
    r, c = cm.shape; bits = []
    for b in format(r, '08b'): bits.append(int(b))
    for b in format(c, '08b'): bits.append(int(b))
    for i in range(r):
        for j in range(c):
            v = int(cm[i, j])
            bits.append((v >> 1) & 1); bits.append(v & 1)
    return bits

def parse_lm(bits):
    if len(bits) < 16: return None
    r = int(''.join(str(b) for b in bits[:8]),  2)
    c = int(''.join(str(b) for b in bits[8:16]), 2)
    if r <= 0 or c <= 0 or r > 512 or c > 512: return None
    if len(bits) < 16 + r * c * 2: return None
    cm = np.zeros((r, c), dtype=np.uint8); idx = 16
    for i in range(r):
        for j in range(c):
            cm[i, j] = (bits[idx] << 1) | bits[idx+1]; idx += 2
    return cm

# Load model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("="*65)
print("  RN-DPE-RDHEI — 1000 IMAGE EVALUATION")
print(f"  Device: {device}")
print("="*65)

model = build_model(device)
model.load_state_dict(torch.load(MODEL_BEST, map_location=device))
model.eval()
print(f"✅ Model loaded\n")

test_files = sorted(os.listdir(TEST_DIR))[:N_TEST]
print(f"  Testing {len(test_files)} images...\n")

base_msg = ("RN-DPE-RDHEI: MED+CNN MAE=0.05, "
    "BRBCC BPP=5.77+, ECDH X25519, "
    "Perm+ZeroFree+XOR NPCR=99.6%, HMAC+ECDSA! "
    "Bassa Srilakshmi 160123737005. "
    "Guide: Mr. N. Shiva Kumar. ")

all_bpp=[]; all_mae=[]; all_npcr=[]; all_uaci=[]; all_ent=[]
psnr_inf=0; ssim_one=0; auth_ok=0; secret_ok=0; failed=0
csv_rows=[]

for idx, fname in enumerate(test_files):
    try:
        original = np.array(Image.open(
            os.path.join(TEST_DIR, fname)).convert('L'), dtype=np.uint8)
        H, W = original.shape

        # MED + CNN
        mp  = med_predictor_fast(original)
        pad = np.pad(original.astype(np.float32)/255.0,
                     ((CONTEXT,CONTEXT),(CONTEXT,CONTEXT)), mode='reflect')
        with torch.no_grad():
            o = model(torch.FloatTensor(pad).unsqueeze(0).unsqueeze(0).to(device))
        cr  = o.squeeze().cpu().numpy()[CONTEXT:CONTEXT+H, CONTEXT:CONTEXT+W] * 30.0
        err = original.astype(np.float32) - np.clip(mp + cr, 0, 255)
        mae = float(np.mean(np.abs(err)))

        # BRBCC
        ld, cap = run_brbcc(err)
        mb = cap['total_payload_bits']
        cm = ld['class_map']; fp = ld['free_plane_ids']
        lmb = build_lm(cm); lms = len(lmb)
        iz  = zero_free(original, cm, fp)

        # Keys
        ap, apub = generate_keypair()
        cp, cpub = generate_keypair()
        sh = compute_shared_secret(ap, cpub)
        nc = generate_nonce()
        ak = derive_keys(sh, nc)
        Ke = ak['Kenc']; Kh = os.urandom(32)

        # Chaos + Encrypt
        H1, H2, H3 = generate_all_sequences(Ke, (H, W))
        enc, ei = encrypt_image(iz, H1, H2, H3, ak['Ksbox'], fp_ids=fp)
        kb = ei['key_bytes']

        # Write locmap
        sc  = mb - lms; rc2 = sc // 8
        khlm = derive_mask(Kh, b"locmap", lms)
        lme  = [lmb[i] ^ int(khlm[i]) for i in range(lms)]
        ewl, _ = scan(enc, cm, fp, skip=0, payload=lme, mode='write')
        sk, vk = generate_signing_keypair()
        pkg = create_secure_package(enc, ak['Kmac'], sk)

        # Embed
        sm  = (base_msg * (rc2 // len(base_msg) + 1))[:rc2]
        sb  = text_to_bits(sm); tb = len(sb)
        khe = derive_mask(Kh, b"embed", tb)
        sx  = [sb[i] ^ int(khe[i]) for i in range(tb)]
        mkd, be = scan(ewl, cm, fp, skip=lms, payload=sx, mode='write')

        # Charlie
        csh = compute_shared_secret(cp, apub)
        ck  = derive_keys(csh, nc)
        H1c,H2c,H3c = generate_all_sequences(ck['Kenc'], (H,W))
        _, eic = encrypt_image(np.zeros((H,W),dtype=np.uint8),
                               H1c,H2c,H3c, ck['Ksbox'], fp_ids=fp)
        kbc = eic['key_bytes']

        # Extract
        lrc2 = scan(mkd, cm, fp, skip=0, payload=lms, mode='read')
        ldc2 = [lrc2[i] ^ int(khlm[i]) for i in range(lms)]
        cmc  = parse_lm(ldc2)
        cm_ok = cmc is not None and np.array_equal(cm, cmc)
        kec2 = derive_mask(Kh, b"embed", tb)
        rw   = scan(mkd, cmc if cm_ok else cm, fp, skip=lms, payload=tb, mode='read')
        sr   = [int(rw[i]) ^ int(kec2[i]) for i in range(len(rw))]
        rt   = bits_to_text(sr)
        s_ok = (rt == sm)

        # Restore + Auth
        rst = restore_free_xor(mkd, cmc if cm_ok else cm, fp, kbc, H, W)
        ap2 = {'encrypted_image': rst, 'hmac_tag': pkg['hmac_tag'],
               'signature': pkg['signature']}
        a_ok = verify_package(ap2, ck['Kmac'], vk)

        # Decrypt + Recover
        rec    = decrypt_image(rst, eic)
        iz_all = zero_all_free(original, fp)
        perfect = np.array_equal(iz_all, rec)

        npcr = float(np.mean(original != enc) * 100)
        uaci = float(np.mean(np.abs(original.astype(float)-enc.astype(float)))/255*100)
        bpp  = be / (H * W)
        hist, _ = np.histogram(enc.flatten(), bins=256, range=(0,256))
        hist = hist[hist > 0].astype(float) / enc.size
        ent  = float(-np.sum(hist * np.log2(hist)))

        all_bpp.append(bpp); all_mae.append(mae)
        all_npcr.append(npcr); all_uaci.append(uaci); all_ent.append(ent)
        if perfect:  psnr_inf += 1; ssim_one += 1
        if a_ok:     auth_ok  += 1
        if s_ok:     secret_ok += 1

        csv_rows.append([fname, f"{bpp:.4f}", f"{mae:.4f}",
                         f"{npcr:.4f}", f"{uaci:.4f}",
                         'inf' if perfect else 'fail',
                         '1.0' if perfect else '0.0',
                         'OK' if a_ok else 'FAIL',
                         'OK' if s_ok else 'FAIL'])

        if (idx+1) % 100 == 0:
            print(f"  [{idx+1:4d}/1000] BPP={np.mean(all_bpp):.4f} | "
                  f"MAE={np.mean(all_mae):.4f} | "
                  f"NPCR={np.mean(all_npcr):.2f}% | "
                  f"Perfect={psnr_inf}/{idx+1}")

    except Exception as e:
        failed += 1
        print(f"  ❌ [{idx+1}] {fname}: {e}")

# Save CSV
os.makedirs(RESULTS_DIR, exist_ok=True)
csv_path = os.path.join(RESULTS_DIR, "eval_1000_results.csv")
with open(csv_path, 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['filename','bpp','mae','npcr','uaci','psnr','ssim','auth','secret'])
    w.writerows(csv_rows)

n = len(all_bpp)
print(f"\n{'='*65}")
print("  FINAL RESULTS — 1000 IMAGE EVALUATION")
print(f"{'='*65}")
print(f"  BPP     (mean) : {np.mean(all_bpp):.4f}")
print(f"  MAE     (mean) : {np.mean(all_mae):.4f}")
print(f"  NPCR    (mean) : {np.mean(all_npcr):.4f}%")
print(f"  UACI    (mean) : {np.mean(all_uaci):.4f}%")
print(f"  Entropy (mean) : {np.mean(all_ent):.4f}")
print(f"  PSNR = ∞       : {psnr_inf}/{n}")
print(f"  SSIM = 1.0     : {ssim_one}/{n}")
print(f"  Auth OK        : {auth_ok}/{n}")
print(f"  Secret OK      : {secret_ok}/{n}")
print(f"  Failed         : {failed}")
print(f"  CSV saved      : {csv_path}")
print(f"{'='*65}")
