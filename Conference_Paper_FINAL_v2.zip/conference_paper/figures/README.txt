PUT YOUR FIGURES HERE:

1. architecture.png
   = Your 11-stage pipeline diagram
   = Show: Original→CNN→BRBCC→Encrypt→Embed→Extract→Decrypt
   = Tool: draw.io (free at diagrams.net)

2. results_comparison.png
   = Bar chart: BPP comparison
   = Methods: MED, ISGAP, BRBCC+MED, OURS

3. prediction_example.png
   = Show: Original image, MED prediction, CNN prediction
   = Show MAE values

HOW TO CREATE ARCHITECTURE DIAGRAM:
1. Go to https://diagrams.net (free)
2. Draw the 11-stage pipeline
3. Export as PNG (300 DPI)
4. Save as figures/architecture.png
